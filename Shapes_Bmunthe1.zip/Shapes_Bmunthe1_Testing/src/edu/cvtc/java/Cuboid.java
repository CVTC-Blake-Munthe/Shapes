package edu.cvtc.java;


public class Cuboid extends Shape implements Renderer {

	//Fields
	private Float width = 0.0f;
	private Float height = 0.0f;
	private Float depth = 0.0f;
	
	//Methods
	
	public Cuboid(Dialog messageBox, double width, double height, double depth) {
		super(messageBox);
		this.width = (float) width;
		this.height = (float) height;
		this.depth = (float) depth;
	}
	
	//Getters and Setters
	public Float getWidth() {
		return this.width;
	}
	
	public void setWidth(Float width) {
		this.width = width;
	}
	
	public Float getHeight() {
		return this.height;
	}
	
	public void setHeight(Float height) {
		this.height = height;
	}
	
	public Float getDepth() {
		return this.depth;
	}
	
	public void setDepth(Float depth) {
		this.depth = depth;
	}
	
	
	@Override
	public float getSurfaceArea() {
		return height*width*6;
	}

	@Override
	public float getVolume() {
		return height*width*depth;
	}

	@Override
	public void render() {
		
		show("Cuboid", "The width of the cuboid is: " + this.getWidth() + "The height of the cuboid is: "
				+ this.getHeight() + "The Depth of the cuboid is: " + this.getDepth());
	}

}
