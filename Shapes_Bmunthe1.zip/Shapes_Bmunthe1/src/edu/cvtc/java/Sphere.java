package edu.cvtc.java;

public class Sphere extends Shape {

	

	//Fields
	private Float radius;
	
	//Methods
	
	//Default Constructor
	public Sphere() {
		radius = (float) 0.0;
	}
	
	//Overloaded Constructor
	public Sphere(double radius) {
		this.radius = (float) radius;
	}
	
	//Getters and Setters
	public Float getRadius() {
		return this.radius;
	}
	
	public void setRadius(Float radius) {
		this.radius = radius;
	}
	
	
	@Override
	float surfaceArea() {
		// TODO Auto-generated method stub
		return (float) (4*Math.PI*Math.pow(radius, 2));
	}

	@Override
	float volume() {
		// TODO Auto-generated method stub
		return (float) ((4/3)*Math.PI*Math.pow(radius, 3));
	}

	@Override
	void render() {
		// TODO Auto-generated method stub

	}

}
