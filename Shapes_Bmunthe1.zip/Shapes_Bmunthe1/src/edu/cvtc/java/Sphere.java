package edu.cvtc.java;


public class Sphere extends Shape implements Renderer {

	

	//Fields
	private Float radius;
	
	//Overloaded Constructor
	public Sphere(Dialog messageBox, double radius) {
		super(messageBox);
		this.radius = (float) radius;
	}
	
	//Getters and Setters
	public Float getRadius() {
		return this.radius;
	}
	
	public void setRadius(Float radius) {
		this.radius = radius;
	}
	
	
	@Override
	public float getSurfaceArea() {
		return (float) (4*Math.PI*Math.pow(radius, 2));
	}

	@Override
	public float getVolume() {
		return (float) ((4/3)*Math.PI*Math.pow(radius, 3));
	}

	@Override
	public void render() {
		
	}


}
