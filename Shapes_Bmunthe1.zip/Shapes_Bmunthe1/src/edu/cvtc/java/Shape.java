package edu.cvtc.java;

public abstract class Shape {

	//Fields
	
	//Methods
	abstract float surfaceArea();
	abstract float volume();
	abstract void render();
	
}
