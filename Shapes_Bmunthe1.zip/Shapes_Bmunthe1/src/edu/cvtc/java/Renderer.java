package edu.cvtc.java;

public interface Renderer {

	public void render();
}
