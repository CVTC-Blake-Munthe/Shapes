package edu.cvtc.java;

public class Cylinder extends Shape {

	//Fields
	private Float radius;
	private Float height;
	
	//Methods
	
	//Default Constructor
	public Cylinder() {
		radius = (float) 0.0;
		height = (float) 0.0;
	}
	
	//Overloaded Constructor
	public Cylinder(double radius, double height) {
		this.radius = (float) radius;
		this.height = (float) height;
	}
	
	//Getters and Setters
	public Float getRadius() {
		return this.radius;
	}
	
	public void setRadius(Float radius) {
		this.radius = radius;
	}
	
	public Float getHeight() {
		return this.height;
	}
	
	public void setHeight(Float height) {
		this.height = height;
	}

	
	@Override
	float surfaceArea() {
		// TODO Auto-generated method stub
		return (float) ((2*Math.PI*radius*height) + (2*Math.PI*Math.pow(radius, 2)));
	}

	@Override
	float volume() {
		// TODO Auto-generated method stub
		return (float) (Math.PI*(Math.pow(radius, 2)*height));
	}

	@Override
	void render() {
		// TODO Auto-generated method stub

	}

}
