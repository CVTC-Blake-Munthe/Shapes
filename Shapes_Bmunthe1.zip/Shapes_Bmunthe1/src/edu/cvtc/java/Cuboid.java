package edu.cvtc.java;

import javax.swing.JOptionPane;

public class Cuboid extends Shape {

	//Fields
	private Float width;
	private Float height;
	private Float depth;
	
	//Methods
	
	//Default Constructor
	public Cuboid() {
		width = (float) 0.0;
		height = (float) 0.0;
		depth = (float) 0.0;
	}
	
	public Cuboid(double width, double height, double depth) {
		this.width = (float) width;
		this.height = (float) height;
		this.depth = (float) depth;
	}
	
	//Getters and Setters
	public Float getWidth() {
		return this.width;
	}
	
	public void setWidth(Float width) {
		this.width = width;
	}
	
	public Float getHeight() {
		return this.height;
	}
	
	public void setHeight(Float height) {
		this.height = height;
	}
	
	public Float getDepth() {
		return this.depth;
	}
	
	public void setDepth(Float depth) {
		this.depth = depth;
	}
	
	
	@Override
	float surfaceArea() {
		return height*width*6;
	}

	@Override
	float volume() {
		return height*width*depth;
	}

	@Override
	void render() {

		String cubeWidth = JOptionPane.showInputDialog("Please enter the width of the cube");
		String cubeHeight = JOptionPane.showInputDialog("Please enter the height of the cube");
		String cubeDepth = JOptionPane.showInputDialog("Please enter the depth of the cube");

	}

}
